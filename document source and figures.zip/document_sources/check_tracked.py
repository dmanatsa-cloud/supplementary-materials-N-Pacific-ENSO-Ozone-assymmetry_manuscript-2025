import sys, zipfile, re, copy
from lxml import etree
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'; q = lambda t: '{%s}%s' % (W, t)
def paras(xml):
    root = etree.fromstring(xml); body = root.find(q('body')); out = []
    for p in body.iter(q('p')):
        t = ''.join(x.text or '' for x in p.iter(q('t'), q('delText')))
        out.append(t)
    return root, out
def texts(root):
    return [''.join(x.text or '' for x in p.iter(q('t'))) for p in root.find(q('body')).iter(q('p'))]
def load(f): return zipfile.ZipFile(f).read('word/document.xml')
def accept(xml):
    root = etree.fromstring(xml)
    for p in list(root.iter(q('p'))):
        rpr = p.find(q('pPr') + '/' + q('rPr'))
        if rpr is not None and rpr.find(q('del')) is not None: p.getparent().remove(p)
    for el in list(root.iter(q('del'))):
        if el.getparent().tag == q('rPr'): continue
        el.getparent().remove(el)
    for el in list(root.iter(q('ins'))):
        par = el.getparent()
        if par.tag == q('rPr'): par.remove(el); continue
        i = par.index(el)
        for ch in list(el): par.insert(i, ch); i += 1
        par.remove(el)
    return root
def reject(xml):
    root = etree.fromstring(xml)
    for p in list(root.iter(q('p'))):
        rpr = p.find(q('pPr') + '/' + q('rPr'))
        if rpr is not None and rpr.find(q('ins')) is not None: p.getparent().remove(p)
    for el in list(root.iter(q('ins'))): el.getparent().remove(el)
    for el in list(root.iter(q('del'))):
        par = el.getparent(); i = par.index(el)
        for ch in list(el):
            for dt in ch.iter(q('delText')): dt.tag = q('t')
            par.insert(i, ch); i += 1
        par.remove(el)
    return root
orig, clean, tracked = [load(f) for f in sys.argv[1:4]]
a = [t for t in texts(accept(tracked))]; c = [t for t in texts(etree.fromstring(clean))]
r = [t for t in texts(reject(tracked))]; o = [t for t in texts(etree.fromstring(orig))]
print('accept==clean', a == c, len(a), len(c)); print('reject==orig', r == o, len(r), len(o))
if a != c:
    for i, (x, y) in enumerate(zip(a, c)):
        if x != y: print('A', i, x[:80], '|', y[:80]); break
if r != o:
    for i, (x, y) in enumerate(zip(r, o)):
        if x != y: print('R', i, x[:80], '|', y[:80]); break
