# -*- coding: utf-8 -*-
# Manuscript revision content, part B (results, discussion, conclusions, back matter).
R49 = ('The fitted ozone response is larger for warm than for cold ENSO forcing of equal amplitude. '
 'With trend, QBO and aerosol controls, the quadratic contrast at ±1°C is +4.8 DU (+1.3 to +8.4 DU), and the hinge contrast is +8.7 DU (−1.7 to +19.1 DU; Table 1 and Figure 2). '
 'The hinge warm slope is +9.2 DU °C⁻¹ (+4.8 to +13.7). The cold slope is +0.5 DU °C⁻¹ (−6.4 to +7.5), close to zero. '
 'The slope difference carries the same uncertainty as the hinge D(1°C). The clearer evidence for a warm slope is therefore not a separate test that the slopes differ. '
 'Solar adjustment changes the quadratic contrast little, to +4.9 DU (+1.3 to +8.5 DU).')
R50 = ('Conditioning on SST pattern weakens both estimates. '
 'Adding the Niño 3 minus Niño 4 contrast gives +4.5 DU (−10.2 to +19.3 DU) for the hinge model and +4.0 DU (−1.4 to +9.5 DU) for the quadratic model. '
 'ONI and this contrast correlate at r=0.87 among winters with ONI ≥0.5°C. '
 'The smaller conditional estimate may therefore reflect removal of ENSO’s own spatial structure, as well as separation of other covariation. '
 'It does not show that the overall association is symmetric.')
R51 = ('The quadratic result is insensitive to trend form. Linear, piecewise-linear (1997 knot) and quadratic trends give primary contrasts of +4.85, +4.87 and +4.89 DU. '
 'Block length matters more. The two-winter-block interval for the 43-winter quadratic estimate includes zero (−0.4 to +8.6 DU), while three- and four-winter blocks narrowly exclude it. '
 'Hinge intervals include zero at all three block lengths. '
 'Omitting 2016, 1998, 1992 or the volcanic winters 1983, 1992 and 1993 leaves primary quadratic contrasts of +4.3 to +4.9 DU, with intervals above zero (Text S3). '
 'RONI substitutions also change the estimates and their uncertainty (Text S3). '
 'These results favour reporting the full model comparison rather than a single verdict on nonlinearity.')
R52 = ('Out-of-sample prediction discriminates only modestly among forms. '
 'With QBO and aerosol, ozone root-mean-square prediction errors are 11.1 DU for the linear, 10.9 DU for the hinge and 10.4 DU for the quadratic model. '
 'With the SST contrast added, they are 10.5, 10.9 and 10.5 DU. '
 'The illustrative 80% detectability threshold for the hinge contrast is about 14.7 DU in the primary specification and 21.0 DU with SST conditioning. '
 'The design therefore has reasonable power only for hinge asymmetries larger than about 15 DU, so wide intervals should not be read as evidence of negligible asymmetry.')
R53 = ('Lower-tropospheric temperature shows the opposite pattern. Its primary quadratic contrast is −0.47 K (−0.87 to −0.07 K; p=0.022; Table 1). '
 'It falls to −0.06 K (−0.56 to +0.44 K) when the SST contrast is held fixed (Table 1). '
 'In the primary specification, ozone and TLT thus depart from symmetry in opposite directions. '
 'This paired sign pattern is consistent with the regional ozone–temperature association, but it does not identify a radiative or dynamical pathway.')
R55 = ('Strong El Niño winters carry large ozone anomalies. The five strong warm winters have a mean detrended MSR2 anomaly of +17.5 DU (9.6 to 24.1 DU). '
 'The five strong cold winters average −4.1 DU (−10.9 to +0.5 DU; Table 2 and Figure 3). '
 'Mean absolute DJF ONI is 2.05°C in the warm group and 1.57°C in the cold group, a ratio of 1.31. '
 'The unscaled composites therefore cannot isolate phase asymmetry on their own. '
 'RSS TLT composites are −1.18 K (−1.57 to −0.73 K) and −0.33 K (−0.80 to +0.51 K). '
 'Both temperature means are negative, so a strong monthly inverse correlation should not be read as a symmetric seasonal response.')
R56 = ('The warm ozone mean stays positive when single extreme winters are removed. It is +15.6 DU without 1998, +15.7 DU without 2016 and +20.9 DU without 1992. '
 'The small 1992 anomaly coincides with high post-Pinatubo aerosol loading. '
 'This motivates the aerosol and volcanic-period sensitivity tests, but it does not identify the cause of that winter’s departure. '
 'The persistence of the warm composite is distinct from evidence for equal-amplitude asymmetry.')
R57 = ('In ERA5, most of the warm-event anomaly lies in the upper troposphere and lower stratosphere. '
 'ERA5 places +10.6 DU (7.2 to 13.1 DU) in 300–100 hPa and +4.6 DU (1.6 to 7.2 DU) in 100–50 hPa (Figure 4). '
 'Together, 300–50 hPa contributes +15.2 DU (8.7 to 20.4 DU). This is about 78% (68–93%) of the +19.5 DU anomaly integrated over 1000–1 hPa. '
 'The 10–1 hPa mean is −0.2 DU (−0.5 to +0.1 DU). '
 'These are shares of the ERA5 pressure integral, not of a closed MSR2 total-column budget. '
 'The cold-phase 300–50 hPa mean is −2.6 DU (−9.9 to +1.4 DU), which is small and uncertain. '
 'Section 3.5 shows that MERRA-2 gives a very similar allocation.')
R58 = ('The accompanying profiles form a coherent picture. The warm-event ozone mixing-ratio anomaly peaks near 50 hPa at about +0.17 ppmv. '
 'Temperature rises by about 2.6 K at 100 hPa and falls by about 1.7 K at 400 hPa (Figure S1). '
 'At 500 hPa, warm-event pressure velocity is −0.02 Pa s⁻¹ and geopotential height is −95 m. The cold-phase values are +0.01 Pa s⁻¹ and +15 m. '
 'This structure is consistent with a lower tropopause above a deeper mid-tropospheric trough. '
 'It provides context for the layer description. '
 'It does not establish a planetary-wave or vortex pathway, a chemical-loss mechanism or a fixed transition in phase symmetry near 50–30 hPa.')
R59 = ('The monthly-profile tropopause proxy supports this picture for El Niño but not for the phase contrast. '
 'Its strong warm-event anomaly is +15.4 hPa (9.6 to 21.8 hPa), compared with −5.5 hPa (−15.1 to +2.7 hPa) in the cold group. '
 'Positive values indicate a lower diagnosed thermal boundary, which is consistent with more ozone in a fixed pressure column. '
 'The proxy correlates with MSR2 ozone at +0.59 within winters and +0.36 between winters. '
 'However, its hinge and quadratic contrasts are +3.2 hPa (−3.8 to +10.2 hPa) and +1.7 hPa (−1.1 to +4.5 hPa). '
 'Neither resolves tropopause-pressure asymmetry, and the coarse monthly diagnostic cannot explain why the cold-phase ozone response is weak.')
R61 = ('Monthly and seasonal associations differ markedly. The within-winter ozone–TLT correlation is −0.77 (95% interval −0.84 to −0.70). '
 'The correlation between detrended winter means is only −0.28 (−0.48 to −0.06). '
 'Their paired difference is −0.49 (−0.71 to −0.30; Figure 5 and Table 3). '
 'The strong inverse monthly relationship therefore carries over only weakly to seasonal means. '
 'The two measures describe different variance components of the same 43 winters.')
R62 = ('The within-winter association does not depend on the strong warm winters. Omitting them leaves a within-winter correlation of −0.77. '
 'The estimates are −0.69 for 1981–2001 and −0.81 for 2002–2023, and consecutive monthly differences give −0.81. '
 'Leaving out one winter at a time gives a narrow range, −0.79 to −0.75 (Text S2). '
 'These checks indicate temporal robustness within this record. They are not an independent replication.')
R63 = ('PNA adjustment sharpens the distinction. The within-winter partial correlation is −0.79 (−0.86 to −0.71), whereas the between-winter partial correlation is −0.13 (−0.30 to +0.14). '
 'A linear PNA adjustment therefore leaves the within-winter association intact. '
 'At the seasonal scale, detrended PNA correlates positively with ozone (r=0.49) and negatively with TLT (r=−0.36), consistent with shared circulation covariation. '
 'These results do not identify which process drives the remaining relationship, and they do not exclude chemical or radiative contributions.')
R64 = ('Further seasonal adjustments give the same picture. Beyond trend, removing QBO gives a between-winter correlation of −0.44. '
 'Removing hinge ENSO terms gives −0.08, and removing ENSO, QBO and aerosol gives −0.27. Quadratic ENSO terms give −0.05 and −0.23 for these two checks. '
 'All remain much weaker than the within-winter −0.77, although unmeasured shared influences cannot be excluded. '
 'ERA5 reproduces the contrast. Its ozone column and atmospheric TLT approximation correlate at −0.79 within winters and −0.38 between winters. '
 'MSR2 with the same temperature approximation gives −0.77 and −0.31 (Text S2). '
 'This replication tests product sensitivity. It is neither an independent satellite retrieval nor an exact TLT reconstruction.')
R66 = ('Winter 2024 stands out. MSR2 ozone was 370.6 DU, or +38.0 DU above the trend fitted over 1981–2023 (Figure 1b). '
 'Models fitted only to those earlier winters underpredict 2024 by 24.2–28.5 DU across quadratic, hinge and linear forms with QBO and aerosol. '
 'Adding solar flux to the nonlinear models still leaves residuals of about 22 DU. '
 'ERA5 gives a contemporaneous 1000–1 hPa anomaly of +32.2 DU, including +23.4 DU at 300–50 hPa (+23.9 DU on the seven common levels). '
 'MERRA-2 gives +35.3 DU over 1000–0.1 hPa, including +24.5 DU at 300–50 hPa. '
 'The three products agree in magnitude, but shared observing systems prevent treating this as independent confirmation. '
 'Winter 2025 has a smaller departure of +13.1 DU. '
 'We examined 2024 after inspecting the extended data, so this comparison is retrospective. It is not an untouched forecast test or evidence of a new regime.')
R67 = ('The extension increases the quadratic estimate. Using all 45 winters, the primary quadratic contrast rises to +5.3 DU (+1.9 to +8.8 DU). '
 'Its percentile intervals are positive for block lengths two through four. '
 'The hinge estimate is +9.8 DU, with a 95% HAC interval of +0.02 to +19.5 DU. Its block-bootstrap intervals still include zero, and the HAC endpoint lies very close to zero. '
 'We therefore avoid a binary significance claim for the hinge form. Adding the SST contrast gives intervals that span zero for both forms (Text S4). '
 'The extension thus adds support for curvature in one representation, while the model dependence remains. '
 'Because the added winters include the retrospectively examined 2024 anomaly, this gain should be weighed with that caveat. '
 'Winter 2024 qualifies as a sixth strong warm winter under the archived ONI rule. It does not qualify under the same strict threshold applied to the archived RONI v5 or v6 series.')
H68 = '3.5 Consistency across reanalyses and satellite profiles'
R69 = ('The vertical description is broadly consistent across products with different coverage. '
 'ERA5 pressure-column and MSR2 total-column anomalies correlate at r=0.975 for detrended winter means. '
 'That agreement supports the ERA5 column, but it does not test the vertical allocation. The layer comparisons below address the allocation directly.')
R69a = ('MERRA-2 reproduces ERA5’s layer variability over the full record (Figure 6; Table S11). '
 'Over the 43 primary winters, detrended 300–50 hPa correlations are 0.961 for winter means and 0.977 for the 129 monthly anomalies. '
 'Omitting all ten strong ENSO winters gives 0.973. '
 'The winter correlation is 0.973 over 1981–2001 and 0.978 over 2002–2023, so agreement does not appear to depend on the Aura-era ozone observations. '
 'The separate 300–100 and 100–50 hPa winter correlations are 0.946 and 0.944. '
 'Mean ERA5-minus-MERRA-2 differences are +1.2, −1.6 and −0.5 DU for 300–100, 100–50 and 300–50 hPa.')
R69b = ('MERRA-2 also gives a similar warm-event vertical allocation. '
 'Its strong El Niño 300–50 hPa mean is +15.8 DU (8.4 to 23.2 DU), compared with +15.2 DU in ERA5. '
 'MERRA-2 places +10.0 DU in 300–100 hPa and +5.8 DU in 100–50 hPa, a slightly larger share in 100–50 hPa than ERA5. '
 'The 300–50 hPa layer holds 82% (62–97%) of MERRA-2’s +19.4 DU anomaly over 1000–1 hPa on its native levels, compared with 78% in ERA5. '
 'Cold-phase layer means are small and uncertain in both reanalyses. The MERRA-2 300–50 hPa mean is +0.9 DU (−8.5 to +7.9 DU). '
 'With trend, QBO and aerosol adjustment, the MERRA-2 300–50 hPa quadratic contrast is +5.2 DU (+0.4 to +10.0 DU), against +3.9 DU (+1.1 to +6.7 DU) in ERA5. '
 'The hinge contrasts are +11.1 DU (−0.05 to +22.3 DU) in MERRA-2 and +8.1 DU (+0.7 to +15.4 DU) in ERA5. '
 'Warm and cold hinge slopes are +9.8 and −1.3 DU °C⁻¹ in MERRA-2, and +8.9 and +0.8 DU °C⁻¹ in ERA5 (Text S5). '
 'The layer asymmetry therefore does not appear to be a feature of ERA5 alone.')
R70 = ('CAMS reproduces the layer variability over 20 winters, 2004–2023 (Figure 7; Figure S3; Table S11). '
 'Detrended winter correlations with ERA5 are 0.986 for 300–100 hPa, 0.949 for 100–50 hPa and 0.970 for 300–50 hPa. '
 'Omitting the strong El Niño winters 2010 and 2016 leaves correlations of 0.977, 0.925 and 0.932, so agreement extends beyond the two warm cases. '
 'The mean ERA5-minus-CAMS difference for 300–50 hPa is +1.4 DU on the common levels but −0.1 DU with ERA5’s extra levels. '
 'The correlation changes only from 0.970 to 0.968. Temporal agreement is thus more robust than the absolute offset. '
 'Agreement is weaker in the lower troposphere, with a detrended winter correlation of 0.19 at 500 hPa.')
R71 = ('OMI provides a satellite-profile check over 15 winters, 2005–2019 (Figure S2; Table S12). In 100–50 hPa it agrees closely with ERA5. '
 'The detrended winter correlation is 0.95, and 0.89 after omitting the four strong ENSO winters. The monthly anomaly correlation is 0.94. '
 'ERA5 is lower than OMI by 2.8 DU on average. '
 'Agreement in 170–100 hPa is weaker. The monthly anomaly correlation is 0.71 and the winter correlation 0.55, falling to −0.12 without the strong winters. '
 'OMI therefore supports the strong-event signal in this layer but not ERA5’s winter-to-winter variability outside the strong ENSO winters. '
 'Nadir retrievals have limited vertical resolution near the tropopause, and averaging kernels were unavailable, so this difference cannot be assigned to either product. '
 'ENSO sensitivity agrees in both layers. Trend-adjusted DJF ONI slopes in 170–100 hPa are +1.85 DU °C⁻¹ (0.20 to 3.50) for OMI and +2.06 DU °C⁻¹ (0.73 to 3.40) for ERA5. '
 'In 100–50 hPa they are +1.75 (0.13 to 3.38) and +1.87 (−0.15 to 3.89) DU °C⁻¹. '
 'Strong El Niño-minus-La Niña differences, 2010 and 2016 against 2008 and 2011, are +9.1 and +8.0 DU in OMI and +7.6 and +8.8 DU in ERA5 (170–100 and 100–50 hPa, respectively). '
 'Matched monthly sampling changes these values little. '
 'SCIAMACHY, 2003–2012, is noisier and gives a weaker ENSO contrast, but the intervals for its slope differences from ERA5 include zero (Text S5; Figure S4).')
R72 = ('SWOOSH was not analysed. Its standard record is zonal mean, and its 20° × 5° gridded version would rely before 2004 on sparse occultation and limb sampling within a single cell (Davis et al., 2016). '
 'MERRA-2 and CAMS provide full-period and Aura-era reanalysis consistency, and OMI provides partial satellite-profile consistency. '
 'Because these products share assimilated ozone observations with ERA5, they do not establish observationally independent validation of the vertical phase response.')
H41 = '4.1 A warm-phase-dominated regional response'
D74 = ('The main result is a fitted ozone response that is larger for warm than for cold ENSO forcing of equal amplitude. '
 'The warm-phase slope is well defined, whereas the cold-phase slope is close to zero and poorly constrained. '
 'The quadratic contrast is positive across trend forms, solar adjustment and influential-winter omissions, and it increases in the 45-winter record. '
 'Block length and conditioning on ENSO-related SST structure affect its uncertainty. '
 'We therefore read the evidence as a warm-phase-dominated regional association, supported most clearly by the quadratic representation. '
 'It is not a demonstration of universal phase nonlinearity under every specification.')
D74a = ('The SST-conditioned estimates need a specific reading. Strong El Niño events are also the most eastern-weighted events, so ENSO amplitude and pattern are partly the same phenomenon (Takahashi et al., 2011; Capotondi et al., 2015). '
 'Holding the Niño 3 minus Niño 4 contrast fixed therefore asks a narrower question. It asks whether ozone asymmetry remains once part of ENSO’s own asymmetry is removed. '
 'The weaker conditional estimates are compatible with an ozone asymmetry that partly reflects the asymmetry of the SST forcing itself. '
 'Indices designed to separate these components, such as the E and C indices of Takahashi et al. (2011), could test this idea further.')
D74b = ('Several known features of ENSO teleconnections could produce a warm-dominated response in this box. '
 'First, La Niña circulation anomalies over the North Pacific are not mirror images of El Niño anomalies, and they are displaced in longitude (Hoerling et al., 1997; Frauen et al., 2014). '
 'The box lies on the eastern flank of the ozone regression field (Figure 1a), where such shifts would matter most. '
 'A fixed box could therefore sample the La Niña response less completely. '
 'Second, the stratospheric pathway appears to respond more clearly to El Niño than to La Niña (Domeisen et al., 2019; Manzini et al., 2024). '
 'The vortex response also depends on the structure of ENSO’s North Pacific teleconnection (Garfinkel and Hartmann, 2008). '
 'Third, strong warm winters show a lower diagnosed tropopause, warming near 100 hPa and a deeper mid-tropospheric trough. '
 'That structure is consistent with the known control of midlatitude column ozone by tropopause height (Steinbrecht et al., 1998). '
 'Our diagnostics cannot separate these candidates. '
 'Phase-resolved regression maps, instantaneous tropopause or potential-vorticity diagnostics, wave-activity fluxes and model experiments with sign-reversed forcing of equal amplitude could test their relative roles.')
H42 = '4.2 Where the anomaly resides'
D75 = ('The vertical allocation appears to be the most robust part of the description. '
 'About four-fifths of the strong warm-event pressure-column anomaly lies between 300 and 50 hPa in both ERA5 and MERRA-2, which use different forecast models and ozone analyses. '
 'MERRA-2 also reproduces the layer’s year-to-year variability over all 43 winters, and CAMS does so over 20 winters. '
 'OMI supports the 100–50 hPa variability and the ENSO slopes in both native layers. '
 'This places the regional ENSO ozone anomaly where tropopause displacement, isentropic mixing and stratosphere-to-troposphere exchange act. '
 'ENSO is known to modulate these processes over the North Pacific (Lin et al., 2015; Albers et al., 2022; Lee et al., 2026). '
 'The results refine the regional magnitude, vertical structure and robustness of an established teleconnection (Wang et al., 2011; Zhang et al., 2015). '
 'They do not identify a new transport pathway or a fixed altitude that separates linear and nonlinear responses.')
D76 = ('The thermal diagnostic adds limited but useful context. A higher diagnosed tropopause pressure and greater ozone coincide in strong warm winters. '
 'This agrees with established ozone–tropopause relationships (Steinbrecht et al., 1998). '
 'The proxy itself, however, shows no resolved phase contrast. '
 'Its coarse vertical resolution and monthly averaging prevent it from measuring actual tropopause displacement, folds or the origin of the weak cold-phase response. '
 'Instantaneous model-level tropopauses or diagnosed potential-vorticity surfaces would be needed for that test. '
 'The fixed 300–50 hPa integral is therefore a descriptive layer, not a tropopause-relative transport or chemical budget.')
H43 = '4.3 What monthly correlations can and cannot show'
D77 = ('The timescale analysis addresses a separate inferential problem. '
 'The strong within-winter ozone–temperature anticorrelation is consistent with familiar tropopause and weather-system variability. '
 'It is not evidence that ozone cools the troposphere. '
 'Between-winter correlations are much weaker, and they remain much weaker than the within-winter value after the seasonal drivers are removed and in the ERA5 replication. '
 'Monthly zero-lag covariation therefore cannot determine the sign, strength or phase symmetry of the seasonal ENSO response. '
 'The distinction is also consistent with both phase-mean temperature composites being negative while monthly ozone and temperature remain inversely related. '
 'The same caution may apply to other studies that infer seasonal teleconnection behaviour from pooled monthly correlations.')
H44 = '4.4 Limitations and an upcoming test'
D78 = ('The product comparisons test consistency, not independence. '
 'ERA5, MERRA-2, CAMS, MSR2 and OMI share some satellite information, and reanalyses can contain observing-system discontinuities and vertically structured biases (Davis et al., 2017). '
 'MERRA-2 agreement is already high over 1981–2001, before its assimilated ozone observations changed in 2004. This reduces, but does not remove, the concern. '
 'The CAMS comparison uses different time-of-day sampling and lacks a historical 30–1 hPa overlap. '
 'OMI covers 15 winters and lacks averaging kernels. In 170–100 hPa it matches the strong-event contrast but not ERA5’s winter-to-winter variability outside the strong ENSO winters, so the lowest layer remains the least constrained. '
 'No longitude-resolved limb record was analysed. '
 'The 2024 anomaly appears in the ERA5 and MERRA-2 pressure columns, but common observational provenance and retrospective selection prevent calling it an independent confirmation.')
D79 = ('The exploratory history of the study also matters. Intervals describe sampling uncertainty under the stated procedures. '
 'They do not capture the selection uncertainty introduced by revising analyses after inspecting the data. '
 'We have therefore kept both functional forms, the short-record limits and the inconclusive diagnostics in view.')
D80 = ('A genuine out-of-sample test is approaching. '
 'In September 2026, NOAA CPC gave a greater than 90% chance of a very strong El Niño during winter 2026–27, based on the Relative ONI (NOAA CPC, 2026). '
 'We have frozen the 1981–2025 linear, hinge and quadratic models and conditional DJF 2027 predictions across ONI values. '
 'We will deposit them publicly before December 2026, so that the coming winter can be evaluated without refitting. '
 'The evaluation will use the archived ONI definition, which differs from the RONI used in the CPC outlook. '
 'Until that deposit, this remains a proposed test rather than a registered forecast.')
C82 = ('Eastern North Pacific winter ozone appears to respond more strongly to El Niño than to La Niña, even when forcing amplitude is held equal. '
 'The warm-phase slope is about +9 DU °C⁻¹, while the cold-phase slope is close to zero. '
 'At ±1°C ONI, the primary quadratic ozone contrast is +4.8 DU and the opposite TLT contrast is −0.47 K. '
 'The wider hinge interval and the SST-conditioned sensitivities qualify this inference. The 45-winter extension strengthens the quadratic result.')
C83 = ('The strong warm-event anomaly lies mainly between 300 and 50 hPa, which holds about four-fifths of the pressure-column anomaly in both ERA5 and MERRA-2. '
 'MERRA-2 reproduces this layer’s winter variability over 1981–2023 and CAMS over 2004–2023. '
 'OMI supports the 100–50 hPa variability and the ENSO slopes over 2005–2019. '
 'These products share observations, so their agreement indicates consistency rather than independent validation.')
C84 = ('Monthly ozone–temperature anticorrelation cannot substitute for seasonal ENSO analysis. '
 'Within-winter correlations remain much stronger than correlations between winter means across all tested adjustments and the ERA5 replication.')
C84a = ('Together, these results give an amplitude-controlled and vertically resolved account of regional ENSO ozone asymmetry, with its statistical, sampling and mechanistic limits stated. '
 'The very strong El Niño forecast for 2026–27 should provide an out-of-sample test of the warm-phase prediction, evaluated with the archived ONI.')
ACK = ('We acknowledge KNMI/TEMIS, ECMWF and the Copernicus Climate Change Service, NASA GMAO and GES DISC, Remote Sensing Systems, NOAA, KIT, the GloSSAC team, NASA GISS, '
 'the Copernicus Atmosphere Monitoring Service and the ESA Ozone CCI team for the data used in this work. '
 'We thank the two reviewers for comments that improved the treatment of ENSO amplitude, temporal aggregation, product consistency and uncertainty.')
DATA = ('The source products and persistent identifiers are listed in Text S1. '
 'The accompanying analysis package contains archived regional inputs, index snapshots, numerical tables, processing and analysis scripts, and figure files, including the MERRA-2 and satellite-profile comparisons. '
 'It preserves the versions used here and separates portable statistical reruns from processing that needs the original gridded or profile archives. '
 'A public repository accession has not yet been assigned.')
AI = ('OpenAI Codex (based on GPT-6) and Anthropic Claude assisted, under the corresponding author’s direction, with data inspection, reconstruction and execution of analyses, literature checks, figure preparation, manuscript drafting and editing, and reviewer responses in September 2026. '
 'Claude assisted with the MERRA-2 and satellite-profile comparisons and the final language revision. '
 'No synthetic observations replaced measured or reanalysis data. '
 'The accompanying disclosure appendix records the scope of assistance. The authors are responsible for the final scientific interpretations and declarations.')
REFS_NEW = {  # key: original reference index after which to insert (in order)
 98: [('Domeisen, D. I. V., Garfinkel, C. I., and Butler, A. H. (2019). The teleconnection of El Niño Southern Oscillation to the stratosphere. Reviews of Geophysics, 57, 5–47. ', 'https://doi.org/10.1029/2018RG000596'),
      ('Frauen, C., Dommenget, D., Tyrrell, N., Rezny, M., and Wales, S. (2014). Analysis of the nonlinearity of El Niño–Southern Oscillation teleconnections. Journal of Climate, 27, 6225–6244. ', 'https://doi.org/10.1175/JCLI-D-13-00757.1'),
      ('Garfinkel, C. I., and Hartmann, D. L. (2008). The different ENSO teleconnections and their effects on the stratospheric polar vortex. Journal of Geophysical Research, 113, D18114. ', 'https://doi.org/10.1029/2008JD009920'),
      ('Gelaro, R., McCarty, W., Suárez, M. J., et al. (2017). The Modern-Era Retrospective Analysis for Research and Applications, Version 2 (MERRA-2). Journal of Climate, 30, 5419–5454. ', 'https://doi.org/10.1175/JCLI-D-16-0758.1'),
      ('Global Modeling and Assimilation Office (GMAO) (2015). MERRA-2 instM_3d_asm_Np: 3d, monthly mean, instantaneous, pressure-level, assimilation, assimilated meteorological fields, V5.12.4. Goddard Earth Sciences Data and Information Services Center (GES DISC). Accessed 26 September 2026. ', 'https://doi.org/10.5067/2E096JV59PK7')],
 100: [('Hoerling, M. P., Kumar, A., and Zhong, M. (1997). El Niño, La Niña, and the nonlinearity of their teleconnections. Journal of Climate, 10, 1769–1786. ', 'https://doi.org/10.1175/1520-0442(1997)010<1769:ENOLNA>2.0.CO;2')],
 107: [('Lin, M., Fiore, A. M., Horowitz, L. W., et al. (2015). Climate variability modulates western US ozone air quality in spring via deep stratospheric intrusions. Nature Communications, 6, 7105. ', 'https://doi.org/10.1038/ncomms8105'),
       ('Manzini, E., Ayarzagüena, B., Calvo, N., and Matei, D. (2024). Nonlinearity and asymmetry of the ENSO stratospheric pathway to North Atlantic and Europe, revisited. Journal of Geophysical Research: Atmospheres, 129, e2023JD039992. ', 'https://doi.org/10.1029/2023JD039992')],
 111: [('NOAA CPC (2026). El Niño/Southern Oscillation (ENSO) diagnostic discussion, issued 10 September 2026. NOAA Climate Prediction Center. Accessed 26 September 2026. ', 'https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_disc_sep2026/ensodisc.shtml'),
       ('Randel, W. J., Garcia, R. R., Calvo, N., and Marsh, D. (2009). ENSO influence on zonal mean temperature and ozone in the tropical lower stratosphere. Geophysical Research Letters, 36, L15822. ', 'https://doi.org/10.1029/2009GL039343'),
       ('Rieder, H. E., Frossard, L., Ribatet, M., et al. (2013). On the relationship between total ozone and atmospheric dynamics and chemistry at mid-latitudes – Part 2: The effects of the El Niño/Southern Oscillation, volcanic eruptions and contributions of atmospheric dynamics and chemistry to long-term total ozone changes. Atmospheric Chemistry and Physics, 13, 165–179. ', 'https://doi.org/10.5194/acp-13-165-2013')],
 112: [('Takahashi, K., Montecinos, A., Goubanova, K., and Dewitte, B. (2011). ENSO regimes: Reinterpreting the canonical and Modoki El Niño. Geophysical Research Letters, 38, L10704. ', 'https://doi.org/10.1029/2011GL047364')],
 114: [('Wargan, K., Labow, G., Frith, S., Pawson, S., Livesey, N., and Partyka, G. (2017). Evaluation of the ozone fields in NASA’s MERRA-2 reanalysis. Journal of Climate, 30, 2961–2988. ', 'https://doi.org/10.1175/JCLI-D-16-0699.1')],
}
CAP136 = ('ERA5 pressure-layer DJF ozone anomalies over 40–50°N, 150–130°W, referenced to each layer’s 1981–2023 linear trend. '
 'Points show means for the strong winters in Table 2, and bars are pointwise 95% episode-bootstrap intervals conditional on the fitted trend. '
 'Pressure is integrated using the available levels. The 300–100 and 100–50 hPa layers together contain most of the warm-event anomaly, and MERRA-2 gives a similar allocation (Figure 6). '
 'These estimates describe a pressure column and do not close a total-ozone budget.')
FIG6_HEAD = 'Figure 6 Regional MERRA-2 and ERA5 layer consistency'
FIG6_CAP = ('(a) Separately detrended DJF 300–50 hPa partial columns over 40–50°N, 150–130°W for the 43 primary winters, 1981–2023. '
 'Strong El Niño (EN) and La Niña (LN) winters are labelled. '
 'Both reanalyses are box-averaged with cosine-latitude weights on their native grids and integrated linearly in pressure on 300, 250, 200, 150, 100, 70 and 50 hPa. '
 '(b) Strong-winter mean anomalies in 300–100 and 100–50 hPa, with pointwise 95% episode-bootstrap intervals. The winters 1999 and 2000 form one La Niña episode. '
 'The two reanalyses share assimilated satellite ozone observations, so the comparison shows consistency rather than independent validation.')
FIG7_HEAD = 'Figure 7 Regional CAMS and ERA5 layer consistency'

NAUJOKAT = 'Naujokat, B. (1986). An update of the observed quasi-biennial oscillation of the stratospheric winds over the tropics. Journal of the Atmospheric Sciences, 43, 1873–1877. https://doi.org/10.1175/1520-0469(1986)043<1873:AUOTOQ>2.0.CO;2'
