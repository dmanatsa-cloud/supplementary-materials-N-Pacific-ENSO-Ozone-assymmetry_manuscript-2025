# -*- coding: utf-8 -*-
import sys, os, json, re
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
sys.path.insert(0, os.path.dirname(__file__))
from ms_a import TITLE
SRC, OUT, LOCS = sys.argv[1:4]
loc = json.load(open(LOCS))
EVID = {
 'R1-major-1': ['d_mech', 'r_profiles', 'r_tp', 'd_thermal'], 'R1-major-2': ['r_comp', 'r_omit'], 'R1-major-3': ['m_oni', 'r_comp'],
 'R1-major-4': ['m_sst', 'r_sst', 'd_sst'], 'R1-major-5': ['m_cov', 'r_profiles'], 'R1-major-6': ['intro1', 'intro2', 'intro6', 'd_vert'],
 'R1-major-7': ['m_merra', 'm_sat', 'r_merra1', 'r_merra2', 'r_omi', 'd_valid'],
 'R1-minor-1': ['r_asym', 'r_merra1'], 'R1-minor-2': ['m_hq', 'm_contrast'], 'R1-minor-3': ['abstract'], 'R1-minor-4': ['intro6', 'd_mech'],
 'R1-minor-5': ['intro6'], 'R1-minor-6': ['r_comp'], 'R1-minor-7': ['r_pna', 'd_ts'], 'R1-minor-8': ['d_vert', 'd_ts'], 'R1-minor-9': ['d_thermal'],
 'R1-minor-10': ['d_mech', 'd_vert'], 'R1-minor-11': ['d_valid', 'c4'],
 'R2-major-1': ['intro3', 'm_contrast', 'r_asym', 'r_comp'], 'R2-major-2': ['r_pna', 'r_ts3', 'r_tp'], 'R2-major-3': ['abstract'],
 'R2-major-4': ['m_layers', 'r_layers'], 'R2-major-5': ['m_contrast', 'r_profiles'],
 'R2-minor-1': ['intro6'], 'R2-minor-2': ['m_oni', 'm_sst'], 'R2-minor-3': ['r_comp', 'r_layers'], 'R2-minor-4': ['r_comp'], 'R2-minor-5': ['r_layers'],
 'R2-minor-6': ['m_data'], 'R2-minor-7': ['r_profiles'], 'R2-minor-8': ['m_data', 'r_profiles'], 'R2-minor-9': ['r_ts1'], 'R2-minor-10': ['m_layers', 'r_layers'],
 'R2-minor-11': ['intro6', 'c4'], 'R2-minor-12': ['m_sat', 'd_valid'], 'R2-minor-13': ['c1', 'c4'], 'R2-minor-14': ['m_hq', 'm_contrast'],
 'R2-minor-15': ['intro6', 'r_ts1'], 'R2-minor-16': ['intro6'],
}
REPLY = {
 'R1-major-1': 'Response. We agree that the original mechanism was not demonstrated, and we have narrowed the interpretation accordingly. The planetary-wave/vortex, sharp altitude-transition and chemical attribution claims have been withdrawn. We added a bounded thermal-structure diagnostic. A lapse-rate criterion applied to regional monthly-mean profiles gives a strong warm-event pressure anomaly of +15.4 hPa, but the hinge and quadratic pressure-asymmetry intervals include zero. Because this proxy is coarse and is diagnosed after monthly averaging, it cannot explain the weak cold-phase ozone response conclusively. Section 4.1 now addresses the reviewer’s three questions as explicit hypotheses. It discusses the longitude displacement of La Niña teleconnections (Hoerling et al., 1997; Frauen et al., 2014), the asymmetric stratospheric pathway (Domeisen et al., 2019; Manzini et al., 2024) and tropopause-height control of column ozone (Steinbrecht et al., 1998). It also names the diagnostics that could separate these candidates, including wave-activity fluxes, instantaneous tropopause or potential-vorticity diagnostics and sign-reversed model experiments. We did not compute Eliassen–Palm fluxes in this revision, so we do not claim a demonstrated pathway. Hu et al. (2022, 2024) are cited in the Introduction, with their different domains and seasons identified.',
 'R1-major-6': 'Response. We have restored ENSO as the principal question and sharpened the statement of novelty. The Introduction now poses three explicit questions and places them in classic and recent work on ENSO teleconnection nonlinearity, the stratospheric pathway and midlatitude ozone (Hoerling et al., 1997; Randel et al., 2009; Takahashi et al., 2011; Rieder et al., 2013; Frauen et al., 2014; Lin et al., 2015; Domeisen et al., 2019; Manzini et al., 2024). The contribution combines equal-amplitude phase-response estimates over 43 winters, an ozone extension through 2025, broad pressure-layer localization and multi-product consistency checks. Warm and cold hinge slopes are +9.2 and +0.5 DU °C⁻¹. The direct hinge contrast remains uncertain, while the primary quadratic contrast is +4.8 DU. The within-versus-between-winter comparison corrects the former zero-lag interpretation and is not presented as a new mechanism or as the paper’s principal discovery.',
 'R1-major-7': 'Response. We agree and have strengthened the validation with MERRA-2 and a longer satellite-profile comparison (Section 3.5, Figures 6 and 7, Text S5, Tables S11 and S12, Figures S2 and S4). MERRA-2 (M2IMNPASM) was processed over the same box and pressure levels for all 43 winters, 1981–2023. The detrended 300–50 hPa winter correlation with ERA5 is 0.96, and 0.97 without the ten strong ENSO winters. It is already 0.97 over 1981–2001, before the Aura era, and 0.98 over 2002–2023. MERRA-2 gives a strong El Niño 300–50 hPa anomaly of +15.8 DU (ERA5 +15.2 DU) and places 82% of its pressure-column anomaly in this layer (ERA5 78%). Its 300–50 hPa quadratic phase contrast is +5.2 DU (+0.4 to +10.0 DU), compared with +3.9 DU in ERA5, so the layer asymmetry does not appear to be specific to ERA5. MSR2 total ozone remains the primary record. ERA5 and MSR2 detrended column anomalies correlate at r=0.975, and the MERRA-2 column correlates with MSR2 at r=0.98. The OMI nadir-profile comparison now covers 15 winters, 2005–2019. In 100–50 hPa the detrended winter correlation is 0.95 (0.89 without strong winters). In 170–100 hPa OMI agrees with ERA5 on the strong-event contrast and the ENSO slope but not on ERA5’s winter-to-winter variability outside the strong ENSO winters (overall winter r=0.55), and the revision states this. SCIAMACHY, 2003–2012, is reported as a noisier secondary check. The CAMS comparison over 2004–2023 is retained (r=0.970). We did not analyse SWOOSH. Its standard record is zonal mean, and its 20° × 5° gridded version would rely before 2004 on sparse limb sampling within one cell. All these products share some assimilated observations with ERA5, so the revision describes the results as consistency rather than independent validation.',
 'R1-minor-1': 'Response. Figures now show the fixed region, both phases, the two response forms, broad pressure layers and the temporal-scale distinction. Regional profiles remain in Figure S1. Composite and regression intervals are shown throughout. The OMI phase contrast, with two winters per phase, is descriptive and is not used for a population significance claim. Figure 6 shows MERRA-2–ERA5 layer consistency over 43 winters, and Figure 7 shows CAMS–ERA5 consistency over 20 winters.',
 'R1-minor-3': 'Response. The abstract has been restructured as a single argument. It opens with the unequal warm- and cold-phase ozone responses and explains why equal-amplitude models are needed. It then reports the ozone and TLT contrasts, the vertical concentration and its consistency across MERRA-2, CAMS and OMI. The temporal-scale result follows as the reason monthly correlations cannot substitute for seasonal ENSO analysis. The abstract asserts no unsupported causal chain.',
 'R1-minor-4': 'Response. Figure 1 now includes coastlines and a closely placed colour bar. The Introduction and caption state that the regression maximum lies west of the retained study box. Its boundaries are inherited from the original analysis and are not optimized from the new regression map. No unique-maximum or whole-basin claim is made. Section 4.1 now discusses how the box’s position on the eastern flank of the response could affect the sampled La Niña signal.',
 'R1-minor-5': 'Response. The abstract, Introduction and methods consistently define the region as the extratropical eastern North Pacific, 40–50°N, 150–130°W. The Introduction describes it as an oceanic region on the eastern flank of the ENSO ozone response.',
 'R1-minor-10': 'Response. The former Section 4.4 has been replaced by a structured Discussion (Sections 4.1–4.4) tied to the reported estimates and the relevant literature. Ozone–tropopause context is supported by Steinbrecht et al. (1998). ENSO teleconnection nonlinearity and the stratospheric pathway are supported by Hoerling et al. (1997), Frauen et al. (2014), Domeisen et al. (2019) and Manzini et al. (2024). Regional ozone teleconnections and transport are supported by Zhang et al. (2015), Lin et al. (2015), Albers et al. (2022) and Lee et al. (2026). Unsupported chemical and climate-impact statements were removed.',
 'R2-minor-12': 'Response. We agree and do not describe the reanalysis comparisons as independent observational validation. CAMS, ERA5, MERRA-2, MSR2 and OMI share some observing-system information. Their regional agreement is described as consistency, with the CAMS time-sampling difference retained. Distant sonde–lidar material has been removed from the manuscript and supplement. MERRA-2 now provides full-period regional consistency and OMI a 15-winter profile check. Because MERRA-2 shares SBUV, OMI and MLS ozone observations with ERA5, it is also described as consistency rather than independent validation.',
 'R2-minor-13': 'Response. The title now reads “' + TITLE + '”. The title and conclusions focus on regional phase asymmetry and its vertical structure. The strong-event pressure-layer concentration is separated from the all-winter equal-amplitude models, and the positive quadratic result is reported alongside the uncertain hinge and SST-conditioned results. No universal altitude boundary between linear and nonlinear response is claimed.',
}
HEAD2 = ('We thank the reviewers for identifying the unequal-amplitude comparison, the insufficient causal evidence and the uncertainty in the vertical ozone analysis. We have substantially revised the scientific framing. The paper now leads with equal-amplitude ENSO phase asymmetry and the vertical concentration of the warm ozone anomaly. Both hinge and quadratic models are reported, with SST-pattern conditioning treated separately. The timescale comparison corrects the earlier monthly zero-lag argument. The ozone record now extends through 2025. We have added the TLT asymmetry, a full-period MERRA-2 layer comparison, regional CAMS comparisons, OMI and SCIAMACHY profile checks and a limited monthly-profile thermal diagnostic, each with its limitations. The literature review has been expanded, and the text has been rewritten in shorter sentences with more cautious claims.')
HEAD3 = ('The planetary-wave/vortex, chemical-loss and total-budget-closure claims have been withdrawn. Candidate explanations for the weak cold-phase response are now discussed as hypotheses. MERRA-2 provides full-period regional layer consistency over 1981–2023, CAMS over 2004–2023 and OMI over 15 winters. SWOOSH was not analysed. The thermal diagnostic is explicitly a monthly-profile proxy, not an instantaneous tropopause analysis. Each numbered reviewer comment is reproduced verbatim. Line ranges below identify the relevant text in the rendered revised manuscript. Text S1–S6, Tables S1–S14 and Figures S1–S4 refer to the separate Supplementary material document.')
def set_text(p, text):
    runs = p.runs
    if not runs: p.add_run(text); return
    runs[0].text = text
    for r in runs[1:]: r._r.getparent().remove(r._r)
def fmt(keys):
    parts = []; seen = set()
    for k in keys:
        for page, a, b in loc[k]:
            if (page, a, b) in seen: continue
            seen.add((page, a, b)); parts.append(f'p. {page}, lines {a}–{b}' if a != b else f'p. {page}, line {a}')
    return 'Revised manuscript: ' + '; '.join(parts) + '.'
d = Document(SRC)
paras = [p for p in d.paragraphs if p.text.strip()]
set_text(paras[1], 'Revised manuscript: ' + TITLE)
assert paras[2].text.startswith('We thank the reviewers') and paras[3].text.startswith('The planetary-wave')
set_text(paras[2], HEAD2); set_text(paras[3], HEAD3)
section = None; key = None; done = set(); removing = False
for p in paras[4:]:
    st = p.style.name; t = p.text.strip()
    if st.startswith('Heading 1') or st == 'Heading1':
        if t.startswith('Response to the pre submission'): removing = True
        elif t.startswith('Reviewer'):
            removing = False; section = ('R1' if 'Reviewer 1' in t else 'R2') + ('-major' if 'major' in t else '-minor')
    if removing:
        p._p.getparent().remove(p._p); continue
    if st.startswith('Heading 2') and t.startswith('Comment'):
        key = f'{section}-{t.split()[1]}'; continue
    if key and t.startswith('Response.') and key in REPLY:
        set_text(p, REPLY[key]); done.add(key + ':reply')
    if key and t.startswith('Revised manuscript:'):
        set_text(p, fmt(EVID[key])); done.add(key)
missing = [k for k in EVID if k not in done]; unused = [k for k in REPLY if k + ':reply' not in done]
print('locations set', len([k for k in done if ':' not in k]), 'missing', missing, 'replies unused', unused)
d.core_properties.revision = 3
d.save(OUT); print('saved', OUT)
