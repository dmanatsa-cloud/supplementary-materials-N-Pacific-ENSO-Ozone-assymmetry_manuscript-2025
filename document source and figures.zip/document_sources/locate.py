# -*- coding: utf-8 -*-
import sys, json, re, subprocess, unicodedata, bisect
def norm(t): return ''.join(c for c in unicodedata.normalize('NFKC', t).casefold() if c.isalnum())
def locations(pdf, ids_json):
    n = int(re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout).group(1))
    entries, flat, starts = [], '', []
    for page in range(1, n + 1):
        txt = subprocess.run(['pdftotext', '-f', str(page), '-l', str(page), '-layout', pdf, '-'], capture_output=True, text=True).stdout
        for line in txt.splitlines():
            if 'Manatsa and Behera |' in line: continue
            m = re.match(r'^\s*(\d+)\s+(.+)$', line)
            if m:
                starts.append(len(flat)); entries.append((page, int(m.group(1)))); flat += norm(m.group(2))
    ids = json.load(open(ids_json, encoding='utf-8')); out = {}
    for k, text in ids.items():
        t = norm(text); s = flat.find(t)
        if s < 0:
            s = flat.find(t[:80]); e = flat.find(t[-80:], s); assert s >= 0 and e >= s, k; stop = e + 80
        else: stop = s + len(t)
        a = bisect.bisect_right(starts, s) - 1; b = bisect.bisect_right(starts, stop - 1) - 1
        rng = {}
        for page, line in entries[a:b + 1]: rng.setdefault(page, []).append(line)
        out[k] = [(p, min(v), max(v)) for p, v in rng.items()]
    return out
if __name__ == '__main__':
    loc = locations(sys.argv[1], sys.argv[2]); json.dump(loc, open(sys.argv[3], 'w'), indent=0)
    for k in ('abstract', 'intro6', 'r_merra1', 'd_mech', 'c4'): print(k, loc[k])
