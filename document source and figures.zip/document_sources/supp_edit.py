# -*- coding: utf-8 -*-
import sys, os, copy, re
from docx import Document
from docx.shared import Inches, Emu
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
from ms_a import TITLE
SRC, OUT, FIG_OMI, FIG_SCIA = sys.argv[1:5]
d = Document(SRC)
P = [p for p in d.paragraphs if p.text.strip() or p._p.xpath('.//w:drawing')]
E = [p._p for p in P]
assert P[46].text.startswith('Figure S2') and P[49].text.startswith('Figure S3') and P[34].text.startswith('The validation hierarchy')
def run(text):
    r = OxmlElement('w:r'); t = OxmlElement('w:t'); t.set(qn('xml:space'), 'preserve'); t.text = text; r.append(t); return r
def set_text(p, text):
    for ch in list(p):
        if ch.tag != qn('w:pPr'): p.remove(ch)
    p.append(run(text))
def new_after(anchor, template, text):
    p = copy.deepcopy(template); set_text(p, text); anchor.addnext(p); return p
T = {
 'intro': 'This supplement gives the data definitions, robustness results, product comparisons and complete event register that support the manuscript. The common ozone–TLT sample is 1981–2023, and ozone-only results extend through 2025. Numerical tables report the calculations actually performed, including results that weaken stronger claims.',
 'merra_src': 'MERRA-2. NASA GMAO collection M2IMNPASM (instM_3d_asm_Np, V5.12.4). Monthly means of 3-hourly instantaneous fields on 42 pressure levels at 0.5° × 0.625°, subset to 40–50°N, 150–130°W for January 1980 to December 2025. https://doi.org/10.5067/2E096JV59PK7',
 'sat_src': 'OMI and SCIAMACHY. C3S/ESA Ozone CCI KNMI nadir-profile monthly 1° product, file version 0006. The archive used here gives 15 complete OMI DJF winters (2005–2019) and 10 complete SCIAMACHY winters (2003–2012). https://doi.org/10.24381/cds.4ebfe4eb',
 's5_first': 'The comparison hierarchy is full-period MERRA-2 consistency (1981–2023), regional CAMS consistency (2004–2023), OMI broad-layer profiles (2005–2019) and a shorter SCIAMACHY check (2003–2012). Distant Hilo and Mauna Loa comparisons have been removed from the paper, and their historical processing records are retained only in the archive. SWOOSH was not analysed. Its standard record is zonal mean, and its 20° × 5° gridded version would depend before 2004 on sparse occultation and limb sampling within one cell (Davis et al., 2016).',
 's5_merra': 'MERRA-2 monthly means (M2IMNPASM) average 3-hourly instantaneous fields, and ERA5 monthly means average all hours, so no time-of-day adjustment is needed. Box means use cosine-latitude weights with boundary gridpoints included. Below-ground fill values occur only at 1000 hPa and are excluded. The ERA5 box means reproduce the package DJF level values exactly. On the common levels, winter correlations over 1981–2023 are 0.946, 0.944 and 0.961 for 300–100, 100–50 and 300–50 hPa, and 0.940, 0.961 and 0.973 without the ten strong ENSO winters (Table S11). Adding ERA5’s intermediate levels at 225, 175 and 125 hPa lowers its 300–50 hPa column by 1.5 DU on average, as in the CAMS comparison. The MERRA-2 1000–0.1 hPa column correlates with detrended MSR2 winter means at r=0.98. For winter 2024, relative to the 1981–2023 trend, MERRA-2 gives +35.3 DU for this column and +24.5 DU in 300–50 hPa, while ERA5 gives +23.9 DU in 300–50 hPa on the same seven levels. For 2025 the MERRA-2 column anomaly is +10.0 DU. With trend, QBO and aerosol controls, the 300–50 hPa hinge contrast is +11.1 DU (−0.05 to +22.3 DU) in MERRA-2 and +8.1 DU (+0.7 to +15.4 DU) in ERA5, and the quadratic contrast is +5.2 DU (+0.4 to +10.0 DU) and +3.9 DU (+1.1 to +6.7 DU). The hinge warm and cold slopes are +9.8 (+5.0 to +14.7) and −1.3 (−8.7 to +6.0) DU °C⁻¹ in MERRA-2, and +8.9 (+5.8 to +11.9) and +0.8 (−4.2 to +5.8) DU °C⁻¹ in ERA5. Strong-event composites use the episode bootstrap of the main text, and their interval ends vary by about 0.3 DU between Monte Carlo runs. In the bootstrap run that gives the MERRA-2 300–50 hPa share of 82% (62–97%), the ERA5 share is 78% (68–92%).',
 's11_note': 'Bias is ERA5 minus the comparison product. CAMS: 60 monthly pairs and 20 winters on the 351-cell common footprint, with monthly values averaging daily 00 UTC analyses; the last column omits 2010 and 2016. MERRA-2: 129 monthly pairs and 43 winters from native-grid box means over 40–50°N, 150–130°W; the last column omits all ten strong ENSO winters (33 winters remain). Monthly anomalies remove calendar means and linear trend, and winter anomalies remove trend. Common pressure levels are 300, 250, 200, 150, 100, 70 and 50 hPa. Both products share modelling lineage or assimilated observations with ERA5. No independent-observation interpretation or grid-cell significance test is made.',
 's12_note': 'OMI uses the 114 pixels valid in both layers in all 45 months, and SCIAMACHY uses 57 pixels over 30 months. ERA5 is remapped to the 1° satellite grid by area overlap. Strong winters inside the records are El Niño 2010 and 2016 (2010 only for SCIAMACHY) and La Niña 2008 and 2011. EN−LN differences are descriptive and are not D(1°C). ONI slopes (DU °C⁻¹) are DJF regressions with a linear trend and ordinary least-squares 95% intervals. ERA5-minus-satellite slope differences are +0.21 (−1.63 to 2.06) and +0.12 (−0.65 to 0.89) DU °C⁻¹ for OMI, and +0.87 (−1.67 to 3.41) and +1.32 (−1.03 to 3.67) DU °C⁻¹ for SCIAMACHY. Mean ERA5-minus-OMI differences are −0.7 and −2.8 DU, with RMS differences of 4.1 and 3.7 DU. Using all valid pixels in each month with matched ERA5 sampling gives OMI winter correlations of 0.56 and 0.95. On the four winters and 149-pixel mask of the earlier comparison, the same code reproduces the previous OMI and ERA5 layer values to within 10⁻¹³ DU. OMI supports the strong-event contrast in 170–100 hPa but not the winter-to-winter variability of ERA5 outside the strong ENSO winters in that layer. Averaging kernels were unavailable, and OMI total-column information enters ERA5.',
 'figS2_head': 'Figure S2 Regional OMI and ERA5 broad-layer comparison',
 'figS2_cap': 'DJF winters 2005–2019. (a, b) Separately detrended DJF means in 170–100 and 100–50 hPa on the 114-pixel common mask, with strong El Niño (EN) and La Niña (LN) winters labelled. (c) Trend-adjusted DJF ONI slopes with ordinary least-squares 95% intervals. ERA5 is remapped by area overlap to the 1° OMI grid and integrated over the same layers. Averaging kernels were unavailable, and the products share observations.',
 'figS4_head': 'Figure S4 Regional SCIAMACHY and ERA5 broad-layer comparison',
 'figS4_cap': 'DJF winters 2003–2012, shown as in Figure S2 on the 57-pixel common mask. SCIAMACHY is a shorter and noisier secondary check. Its ENSO contrast is weaker than in ERA5, but the intervals for the slope differences include zero.',
}
S11 = [['Table S11 Product,\nperiod', 'Layer\nhPa', 'Bias\nDU', 'Monthly RMS\nDU', 'Monthly\nanomaly r', 'Winter\nanomaly r', 'Winter r, strong\nwinters omitted'],
 ['CAMS\n2004–2023', '300–100', '1.4', '1.9', '0.991', '0.986', '0.977'], ['', '100–50', '0.0', '1.5', '0.971', '0.949', '0.925'], ['', '300–50', '1.4', '2.7', '0.985', '0.970', '0.932'],
 ['MERRA-2\n1981–2023', '300–100', '1.2', '2.6', '0.965', '0.946', '0.940'], ['', '100–50', '−1.6', '3.4', '0.960', '0.944', '0.961'], ['', '300–50', '−0.5', '4.3', '0.977', '0.961', '0.973']]
S11W = [2016, 936, 864, 1152, 1152, 1152, 2376]
S12 = [['Table S12 Sensor,\nwinters', 'Layer\nhPa', 'Monthly\nanomaly r', 'Winter\nr', 'Winter r,\nstrong omitted', 'ERA5 − sat.\nDU', 'EN − LN\nsat. / ERA5 DU', 'ONI slope\nsatellite', 'ONI slope\nERA5'],
 ['OMI\n2005–2019 (15)', '170–100', '0.71', '0.55', '−0.12', '−0.7', '9.1 / 7.6', '1.85 (0.20, 3.50)', '2.06 (0.73, 3.40)'],
 ['', '100–50', '0.94', '0.95', '0.89', '−2.8', '8.0 / 8.8', '1.75 (0.13, 3.38)', '1.87 (−0.15, 3.89)'],
 ['SCIAMACHY\n2003–2012 (10)', '170–100', '0.66', '0.49', '0.09', '1.8', '3.2 / 8.2', '1.22 (0.06, 2.37)', '2.09 (−0.32, 4.49)'],
 ['', '100–50', '0.74', '0.72', '0.78', '−5.8', '3.1 / 8.1', '1.47 (−0.81, 3.75)', '2.79 (−0.07, 5.65)']]
S12W = [1230, 860, 820, 760, 860, 780, 1040, 1650, 1650]
def fill(tc, text, width):
    tc.find(qn('w:tcPr')).find(qn('w:tcW')).set(qn('w:w'), str(width))
    p = tc.find(qn('w:p'))
    for extra in tc.findall(qn('w:p'))[1:]: tc.remove(extra)
    r = p.find(qn('w:r')); rpr = r.find(qn('w:rPr'))
    for ch in list(p):
        if ch.tag != qn('w:pPr'): p.remove(ch)
    nr = OxmlElement('w:r')
    if rpr is not None: nr.append(copy.deepcopy(rpr))
    for k, part in enumerate(text.split('\n')):
        if k: nr.append(OxmlElement('w:br'))
        t = OxmlElement('w:t'); t.set(qn('xml:space'), 'preserve'); t.text = part; nr.append(t)
    p.append(nr)
def rebuild(tbl, data, widths, size=None):
    rows = tbl.findall(qn('w:tr')); hdr, body = rows[0], rows[1]
    th = [copy.deepcopy(hdr.findall(qn('w:tc'))[j]) for j in (0, 1)]; tb = [copy.deepcopy(body.findall(qn('w:tc'))[j]) for j in (0, 1)]
    grid = tbl.find(qn('w:tblGrid'))
    for g in list(grid): grid.remove(g)
    for w in widths: g = OxmlElement('w:gridCol'); g.set(qn('w:w'), str(w)); grid.append(g)
    trh, trb = copy.deepcopy(hdr.find(qn('w:trPr'))), copy.deepcopy(body.find(qn('w:trPr')))
    for r in rows: tbl.remove(r)
    for i, row in enumerate(data):
        tr = OxmlElement('w:tr'); tr.append(copy.deepcopy(trh if i == 0 else trb))
        for j, v in enumerate(row):
            tc = copy.deepcopy((th if i == 0 else tb)[0 if j == 0 else 1]); fill(tc, v, widths[j])
            if size:
                for sz in tc.iter(qn('w:sz')): sz.set(qn('w:val'), str(size))
            tr.append(tc)
        tbl.append(tr)
tabs = {t.rows[0].cells[0].text.split()[1]: t for t in d.tables if t.rows[0].cells[0].text.startswith('Table S')}
rebuild(tabs['S11']._tbl, S11, S11W); rebuild(tabs['S12']._tbl, S12, S12W, size=17)
set_text(E[1], TITLE); set_text(E[2], T['intro'])
new_after(E[5], E[5], T['merra_src']); set_text(E[13], T['sat_src'])
set_text(E[34], T['s5_first']); new_after(E[34], E[34], T['s5_merra'])
set_text(E[35], T['s11_note']); set_text(E[37], T['s12_note'])
set_text(E[46], T['figS2_head']); set_text(E[48], T['figS2_cap'])
# replace the Figure S2 image in place, preserving width and updating the height
blip = E[47].xpath('.//a:blip')[0]; rid = blip.get(qn('r:embed')); part = d.part.related_parts[rid]
part._blob = open(FIG_OMI, 'rb').read()
w0 = int(E[47].xpath('.//wp:extent')[0].get('cx')); im = Image.open(FIG_OMI); h0 = int(w0 * im.size[1] / im.size[0])
for ext in E[47].xpath('.//wp:extent') + E[47].xpath('.//a:ext'): ext.set('cy', str(h0))
# Figure S4 after Figure S3 caption
h = copy.deepcopy(E[49]); set_text(h, T['figS4_head'])
tmp = d.add_paragraph(); tmp.add_run().add_picture(FIG_SCIA, width=Emu(w0)); pic = tmp._p; pic.getparent().remove(pic)
pp = E[50].find(qn('w:pPr'))
if pp is not None: pic.insert(0, copy.deepcopy(pp))
c = copy.deepcopy(E[51]); set_text(c, T['figS4_cap'])
E[51].addnext(h); h.addnext(pic); pic.addnext(c)
cp = d.core_properties; cp.revision = 3
d.save(OUT); print('saved', OUT)
