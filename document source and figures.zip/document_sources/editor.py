# -*- coding: utf-8 -*-
"""Apply OPS to the submitted manuscript. mode 'clean' writes the revised text; mode 'tracked' writes the same
edits as Word tracked changes (w:ins / w:del) against the original."""
import sys, os, copy, re, difflib, json
from docx import Document
from docx.shared import Inches
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
sys.path.insert(0, os.path.dirname(__file__))
from ops import OPS
SRC, OUT, MODE, FIGPATH = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
AUTHOR, DATE = 'D. Manatsa', '2026-09-26T12:00:00Z'
d = Document(SRC)
P = [p for p in d.paragraphs if p.text.strip() or p._p.xpath('.//m:oMath') or p._p.xpath('.//w:drawing')]
assert P[0].text.startswith('ENSO phase asymmetry') and P[140].text.startswith('Figure 6') and P[115].text.startswith('Zhang'), 'index map changed'
E = [p._p for p in P]
nid = [1000]
def mark(tag):
    el = OxmlElement('w:' + tag); el.set(qn('w:id'), str(nid[0])); el.set(qn('w:author'), AUTHOR); el.set(qn('w:date'), DATE); nid[0] += 1; return el
def run(text, deleted=False):
    r = OxmlElement('w:r'); t = OxmlElement('w:delText' if deleted else 'w:t'); t.set(qn('xml:space'), 'preserve'); t.text = text; r.append(t); return r
def wrap(tag, *runs):
    w = mark(tag)
    for r in runs: w.append(r)
    return w
def clear_runs(p):
    for ch in list(p):
        if ch.tag != qn('w:pPr'): p.remove(ch)
def set_text(p, new, track):
    old = ''.join(t.text or '' for t in p.iter(qn('w:t')))
    if old == new: return
    clear_runs(p)
    if not track: p.append(run(new)); return
    a, b = re.findall(r'\S+\s*', old), re.findall(r'\S+\s*', new)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    if sm.ratio() < 0.45:
        p.append(wrap('del', run(old, True))); p.append(wrap('ins', run(new))); return
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == 'equal': p.append(run(''.join(a[i1:i2])))
        if op in ('delete', 'replace'): p.append(wrap('del', run(''.join(a[i1:i2]), True)))
        if op in ('insert', 'replace'): p.append(wrap('ins', run(''.join(b[j1:j2]))))
def mark_para_inserted(p):
    pPr = p.find(qn('w:pPr'))
    if pPr is None: pPr = OxmlElement('w:pPr'); p.insert(0, pPr)
    rPr = pPr.find(qn('w:rPr'))
    if rPr is None: rPr = OxmlElement('w:rPr'); pPr.append(rPr)
    rPr.append(mark('ins'))
TEMPL = {'body': E[11], 'h2': E[17], 'fighead': E[140], 'figpic': E[141], 'caption': E[142]}
def new_para(kind, text, track):
    p = copy.deepcopy(TEMPL[kind]); clear_runs(p)
    p.append(wrap('ins', run(text)) if track else run(text))
    if track: mark_para_inserted(p)
    return p
def ref_para(text, url, track):
    p = OxmlElement('w:p'); rid = d.part.relate_to(url, RT.HYPERLINK, is_external=True)
    h = OxmlElement('w:hyperlink'); h.set(qn('r:id'), rid)
    r2 = run(url); rpr = OxmlElement('w:rPr'); c = OxmlElement('w:color'); c.set(qn('w:val'), '000000'); rpr.append(c); r2.insert(0, rpr)
    if track: p.append(wrap('ins', run(text))); h.append(wrap('ins', r2)); mark_para_inserted(p)
    else: p.append(run(text)); h.append(r2)
    p.append(h); return p
track = MODE == 'tracked'; ids = {}
for op in OPS:
    kind = op[0]
    if kind == 'set':
        _, i, text, pid = op; set_text(E[i], text, track); ids[pid] = text
    elif kind in ('after', 'before'):
        _, i, items = op; cur = E[i]
        for k, text, pid in items:
            np_ = new_para(k, text, track); ids[pid] = text
            if kind == 'after': cur.addnext(np_); cur = np_
            else: E[i].addprevious(np_)
    elif kind == 'refs_after':
        _, i, refs = op; cur = E[i]
        for text, url in refs:
            np_ = ref_para(text, url, track); cur.addnext(np_); cur = np_
    elif kind == 'move_after':
        _, i, j = op; src, dst = E[i], E[j]
        if not track:
            src.getparent().remove(src); dst.addnext(src)
        else:
            new = copy.deepcopy(src)
            for r in list(src.iter(qn('w:r'))):
                if r.getparent().tag == qn('w:del'): continue
                for t in r.findall(qn('w:t')): t.tag = qn('w:delText')
                par = r.getparent(); k = par.index(r); w = mark('del'); par.insert(k, w); w.append(r)
            pPr = src.find(qn('w:pPr'))
            if pPr is None: pPr = OxmlElement('w:pPr'); src.insert(0, pPr)
            rPr = pPr.find(qn('w:rPr'))
            if rPr is None: rPr = OxmlElement('w:rPr'); pPr.append(rPr)
            rPr.append(mark('del'))
            for r in list(new.iter(qn('w:r'))):
                par = r.getparent(); k = par.index(r); w = mark('ins'); par.insert(k, w); w.append(r)
            mark_para_inserted(new); dst.addnext(new); E[i] = new
    elif kind == 'figure_before':
        _, i, head, key, cap, pid = op; anchor = E[i]
        h = new_para('fighead', head, track)
        tmp = d.add_paragraph(); r = tmp.add_run(); r.add_picture(FIGPATH, width=Inches(6.5))
        pic = tmp._p; pic.getparent().remove(pic)
        pPr = copy.deepcopy(TEMPL['figpic'].find(qn('w:pPr'))); pic.insert(0, pPr)
        if track:
            rr = pic.find(qn('w:r')); pic.remove(rr); pic.append(wrap('ins', rr)); mark_para_inserted(pic)
        c = new_para('caption', cap, track); ids[pid] = cap
        for el in (h, pic, c): anchor.addprevious(el)
cp = d.core_properties; cp.revision = 3; cp.last_modified_by = 'Manuscript revision'
d.save(OUT)
json.dump(ids, open(os.path.splitext(OUT)[0] + '_ids.json', 'w'), ensure_ascii=False, indent=0)
print('saved', OUT, MODE, 'changes', nid[0] - 1000)
